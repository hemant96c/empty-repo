import boto3
import requests
import base64
import json
import os

def lambda_handler(event, context):

   
    payload = {
	  "subnet_id": "os.subnet",
	  "name": "HEMANT COUDHARY",
	  "email": "<hemantc@pre-scient.com>"
	}

   
    json_payload = json.dumps(payload)

    url = "https://ij92qpvpma.execute-api.eu-west-1.amazonaws.com/candidate-email_serverless_lambda_stage/data"
    headers = {
        "Content-Type": "application/json",
        "X-Siemens-Auth": "test"
    }

    response = requests.post(url, headers=headers, data=json_payload)

    response_data = response.json()

    print("Response Data:", response_data)

    return {
        "statusCode": response.status_code,
        "body": json.dumps(response_data), 
        "Message" : "API endpoint invoked successfully"
    }
